#!/bin/bash

pkill ldmsd

ldmsd -x sock:10001 -l /root/ldmscon2024/basic/logs/start_ldms_sampler.log -c /root/ldmscon2024/basic/conf/e1/sampler.conf

ldms_ls -p 10001
ldms_ls -p 10001 -l
ldms_ls -p 10001 -v
