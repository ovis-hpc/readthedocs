#!/bin/bash

pkill ldmsd

ldmsd -x sock:10001 -l /root/ldmscon2024/basic/logs/start_ldms_sampler.log -c /root/ldmscon2024/basic/conf/e1/sampler.conf
ldmsd_controller -p 10001 --source path=/root/ldmscon2024/basic/conf/e1/ldmsd_controller_sampler_3.conf

ldmsd -x sock:20001 -l /root/ldmscon2024/basic/logs/start_ldms_simple_agg.log -c
/root/ldmscon2024/basic/conf/e2/aggregator.conf

ldms_ls -p 20001
ldms_ls -p 20001 -l
ldms_ls -p 20001 -v