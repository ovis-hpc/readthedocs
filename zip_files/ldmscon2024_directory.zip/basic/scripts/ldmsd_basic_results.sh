#!/bin/bash

# start sampler on node-1 for meminfo
echo "\nStarting LDMS daemon sampler on node-1\n"
ldmsd -x sock:10001 -l /root/ldmscon2024/basic/logs/start_ldms_sampler.log -c /root/ldmscon2024/basic/conf/e1/sampler.conf
echo "\nChecking the sampler proccess exists\n"
ps auwx | grep ldmsd
sleep 5
echo "\nQuerying LDMSD sampler\n"
ldms_ls -h localhost -p 10001
sleep 5
echo "\nQuerying LDMSD sampler metric values and outputting only first few lines\n"
ldms_ls -h localhost -p 10001 -l | head
sleep 5
echo "\nQuerying LDMSD sampler meta-data\n"
ldms_ls -h localhost -p 10001 -v
sleep 5

# add vmstat plugin to sampler on node-1
echo "\nAdding vmstat plugin to LDMSD sampler\n"
ldmsd_controller -p 10001 --source path=/root/ldmscon2024/basic/conf/e1/ldmsd_controller_sampler_3.conf
echo "\nQuerying LDMSD sampler\n"
ldms_ls -h localhost -p 10001
sleep 5

# start sampler on node-2 for meminfo
echo "\nStarting LDMSD sampler on node-2\n"
pdsh -w node-2 'ldmsd -x sock:10001 -l /root/ldmscon2024/basic/logs/sampler2.log -c /root/ldmscon2024/basic/conf/e1/sampler.conf'

# start ldmsd to aggregate sampler data and store to csv file
echo "\nStarting LDMSD aggregator on node-1 to aggregate samplers and store to csv file\n"
ldmsd -x sock:20001 -l /root/ldmscon2024/basic/logs/start_agg_store_csv.log -c /root/ldmscon2024/basic/conf/e3/agg_store_csv.conf -v DEBUG
echo "\nChecking the aggregator process exists\n"
ps auwx | grep ldmsd
sleep 5

# query the aggregator
echo "\nQuerying the LDMSD aggregator\n"
ldms_ls -h localhost -p 20001
sleep 5
echo "\nQuerying the LDMSD aggregator meta-data\n"
ldms_ls -h localhost -p 20001 -v
sleep 5

# view csv file contents
echo "\nChecking the csv files exist\n"
ls -ltrch /root/ldmscon2024/basic/data/memory_metrics/
sleep 3
echo "\nViewing the stored meminfo and vmstat data, repectively\n"
head /root/ldmscon2024/basic/data/memory_metrics/meminfo
sleep 3
head /root/ldmscon2024/basic/data/memory_metrics/vmstat | head

# kill daemons and remove log file and data
echo "\nKilling all LDMS daemons, removing log files and data\n"
pkill ldmsd
pdsh -w node-2 'pkill ldmsd'
rm -rf /root/ldmscon2024/basic/logs/*
rm -rf /root/ldmscon2024/basic/data/*
